function [x, lam, mu, z, ok] = lipm_project(x, lam, mu, z)
%LIPM_PROJECT  GI-LSTM central-path projection hook, called from mips.m.
%
%   Reads the first K logged iterates of the current run from ipm_logger,
%   calls the trained GI-LSTM (Python, lipm_infer.predict), applies the
%   acceptability screen and, if it passes, returns the projected
%   primal/dual/slack state for IPM to continue from.  On any failure the
%   original state is returned unchanged with ok = false (classical IPM
%   simply continues).
%
%   Scenario data is passed through  getappdata(0, 'lipm')  by LIPM_run.m:
%     .K, .Pd, .Qd, .nx, .nlam, .nmu, .tol_ineq, .tol_bal

ok = false;
S  = getappdata(0, 'lipm');
try
    R = ipm_logger('get_run');                       % rows logged so far in this run
    if size(R, 1) < S.K, return; end
    seq = R(1:S.K, 12:end);                          % [x; lam; mu; z] for iterations 1..K
    t0  = tic;
    res = py.lipm_infer.predict(reshape(seq', 1, []), S.Pd(:)', S.Qd(:)');
    S.infer_time = toc(t0);
    y        = double(res{1});
    S.max_ineq = double(res{2});
    S.max_bal  = double(res{3});

    if S.max_ineq <= S.tol_ineq && S.max_bal <= S.tol_bal
        nx = S.nx; nl = S.nlam; nm = S.nmu;
        x   = y(1:nx)';
        lam = y(nx+1:nx+nl)';
        mu  = y(nx+nl+1:nx+nl+nm)';
        z   = y(nx+nl+nm+1:nx+nl+2*nm)';
        ok  = true;
    end
    S.applied = ok;
    setappdata(0, 'lipm', S);
catch ME
    warning('lipm_project:failed', '%s -- continuing with classical IPM', ME.message);
end
end
