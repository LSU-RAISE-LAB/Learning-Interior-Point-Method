function out = ipm_logger(cmd, varargin)
%IPM_LOGGER  Buffer MIPS iteration history in memory; write to Excel or .mat.
%
%   ipm_logger('init', file, keep_iters)   reset buffer. keep_iters = Inf (all
%                                          iterations) or n (first n + final)
%   ipm_logger('new_run', run_id, meta)    start a new OPF scenario
%   ipm_logger('log', History_row, x)      append one iteration (called from mips.m)
%   ipm_logger('end_run', success, it, f)  record scenario outcome
%   ipm_logger('flush')                    write to disk (Excel: overwrite file;
%                                          .mat: write a chunk file and free memory)
%
%   History row layout:
%   run_id | feascond gradcond compcond costcond iter gamma norm_dx f alphap alphad | x_1 ... x_n
%
%   .mat chunk files are saved in single precision and named <file>_partNN.mat.
%   Each chunk holds H, hdr (history rows + column names) and S, shdr (summary of
%   ALL scenarios so far, so the last chunk's S is the complete summary).

persistent buf nrow run_id fname summary nsum enabled keep runbuf nrun nchunk
out = [];

switch lower(cmd)
    case 'init'
        fname = varargin{1};
        if nargin > 2, keep = varargin{2}; else, keep = Inf; end
        buf     = zeros(20000, 0);  nrow = 0;
        summary = zeros(2000, 0);   nsum = 0;
        runbuf  = zeros(200, 0);    nrun = 0;
        run_id  = 0;  nchunk = 0;   enabled = true;

    case 'new_run'
        run_id = varargin{1};
        if nargin > 2, meta = varargin{2}(:)'; else, meta = []; end
        row  = [run_id, NaN, NaN, NaN, meta];
        nsum = nsum + 1;
        summary = grow(summary, nsum, numel(row));
        summary(nsum, :) = row;
        nrun = 0;

    case 'log'
        if isempty(enabled) || ~enabled, return; end
        hist_row = varargin{1}(:)';
        if nargin > 2, x = varargin{2}(:)'; else, x = []; end
        row  = [run_id, hist_row, x];
        nrun = nrun + 1;
        runbuf = grow(runbuf, nrun, numel(row));
        runbuf(nrun, :) = row;

    case 'end_run'
        if nsum > 0
            summary(nsum, 2:4) = [varargin{1}, varargin{2}, varargin{3}];
        end
        if nrun > 0
            if isinf(keep) || nrun <= keep + 1
                sel = 1:nrun;
            else
                sel = [1:keep, nrun];          % first `keep` iterations + final
            end
            R   = runbuf(sel, :);
            buf = grow(buf, nrow + size(R,1), size(R,2));
            buf(nrow+1:nrow+size(R,1), :) = R;
            nrow = nrow + size(R,1);
        end
        nrun = 0;

    case 'flush'
        if isempty(fname), error('ipm_logger: call init first'); end
        H  = buf(1:nrow, :);
        S  = summary(1:nsum, :);
        nx = size(H, 2) - 11;
        hdr  = [{'run_id','feascond','gradcond','compcond','costcond','iter', ...
                 'gamma','norm_dx','f','alphap','alphad'}, ...
                arrayfun(@(k) sprintf('x_%d', k), 1:nx, 'UniformOutput', false)];
        shdr = [{'run_id','success','iterations','f'}, ...
                arrayfun(@(k) sprintf('alpha_%d', k), 1:size(S,2)-4, 'UniformOutput', false)];

        use_mat = endsWith(fname, '.mat') || size(H,2) > 16384 || numel(H) > 5e6;
        if use_mat
            % ---- chunked .mat output, single precision, then free memory ----
            nchunk  = nchunk + 1;
            matfile = regexprep(fname, '\.mat$|\.xlsx$', sprintf('_part%02d.mat', nchunk));
            H = single(H);
            save(matfile, 'H', 'hdr', 'S', 'shdr', '-v7.3');
            fprintf('ipm_logger: wrote %d rows (chunk %d) to %s\n', nrow, nchunk, matfile);
            buf = zeros(20000, 0);  nrow = 0;
            return
        end

        % ---- Excel output (small systems): overwrite whole file each flush ----
        try
            writecell(hdr,  fname, 'Sheet', 'History', 'Range', 'A1');
            writematrix(H,  fname, 'Sheet', 'History', 'Range', 'A2');
            writecell(shdr, fname, 'Sheet', 'Summary', 'Range', 'A1');
            writematrix(S,  fname, 'Sheet', 'Summary', 'Range', 'A2');
            fprintf('ipm_logger: wrote %d rows, %d scenarios to %s\n', nrow, nsum, fname);
        catch ME
            alt = strrep(fname, '.xlsx', ['_' datestr(now, 'yyyymmdd_HHMMSS') '.xlsx']);
            warning('ipm_logger: could not write %s (%s); writing %s instead', ...
                    fname, ME.message, alt);
            writecell(hdr,  alt, 'Sheet', 'History', 'Range', 'A1');
            writematrix(H,  alt, 'Sheet', 'History', 'Range', 'A2');
            writecell(shdr, alt, 'Sheet', 'Summary', 'Range', 'A1');
            writematrix(S,  alt, 'Sheet', 'Summary', 'Range', 'A2');
        end

    case 'get'
        out = buf(1:nrow, :);

    case 'get_run'
        out = runbuf(1:nrun, :);      % rows logged so far in the current run

    case 'disable'
        enabled = false;

    case 'enable'
        enabled = true;

    otherwise
        error('ipm_logger: unknown command "%s"', cmd);
end
end

function M = grow(M, n, ncol)
% ensure M has at least n rows and ncol columns
if size(M, 2) < ncol, M(:, end+1:ncol) = 0; end
if n > size(M, 1),    M(end+1:max(2*end, n), :) = 0; end
end
