"""
bench_infer.py -- pure GI-LSTM inference time (model already loaded, nothing else timed).

Run inside the lipm env, from the folder that holds lipm_infer.py:
    python bench_infer.py                        # system/opf taken from lipm_infer.py
    python bench_infer.py --system 24bus --opf acopf --reps 500

Reports, in milliseconds, the median / mean / min / 95th percentile of
  (a) network forward pass, graph-compiled (tf.function)  -> "pure model compute"
  (b) network forward pass, eager Keras call               -> what lipm_infer.predict uses
  (c) full predict(): standardize + model + clip + screen residuals (Python side only)
Timing uses time.perf_counter around the call only; a result is forced with .numpy()
so TensorFlow cannot defer the work.  No printing happens inside the timed region.
"""
import os, sys, time, argparse
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument('--system', default=None)
ap.add_argument('--opf', default=None)
ap.add_argument('--model_file', default=None, help='python module with GILSTM (default gi_lstm_<system>_<opf>)')
ap.add_argument('--reps', type=int, default=300)
ap.add_argument('--warm', type=int, default=30)
ap.add_argument('--threads', type=int, default=1, help='TF intra/inter-op threads (1 = same as the MATLAB runs)')
args = ap.parse_args()

import tensorflow as tf
tf.config.threading.set_intra_op_parallelism_threads(args.threads)
tf.config.threading.set_inter_op_parallelism_threads(args.threads)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lipm_infer as LI
if args.system:     LI.SYSTEM = args.system
if args.opf:        LI.OPF = args.opf
if args.model_file: LI.MODEL_FILE = args.model_file
elif args.system or args.opf: LI.MODEL_FILE = f'gi_lstm_{LI.SYSTEM}_{LI.OPF}'
if args.system or args.opf or args.model_file:
    import importlib; LI.G = importlib.import_module(LI.MODEL_FILE); LI._S.clear()

S = LI._load()                                   # ---- loading: NOT timed ----
model, K, n, n_load, nb = S['model'], S['K'], S['n_state'], S['n_load'], S['nb']
n_params = int(sum(np.prod(w.shape) for w in model.weights))

# one realistic-looking standardized input (timing does not depend on the values)
rng = np.random.default_rng(0)
Xs = rng.standard_normal((1, K, n)).astype(np.float32)
Ls = rng.standard_normal((1, n_load)).astype(np.float32)
Xt, Lt = tf.constant(Xs), tf.constant(Ls)

@tf.function(reduce_retracing=True)
def fwd(x, l):
    return model((x, l), training=False)

def bench(fn, reps, warm):
    for _ in range(warm):
        fn()
    t = np.empty(reps)
    for i in range(reps):
        t0 = time.perf_counter(); fn(); t[i] = time.perf_counter() - t0
    t *= 1e3
    return dict(median=np.median(t), mean=t.mean(), min=t.min(), p95=np.percentile(t, 95), std=t.std())

# (a) graph-compiled forward pass -- pure model compute
ra = bench(lambda: fwd(Xt, Lt).numpy(), args.reps, args.warm)
# (b) eager Keras call, exactly as lipm_infer.predict does it
rb = bench(lambda: model((Xs, Ls), training=False).numpy(), args.reps, args.warm)
# (c) full predict(): pre-processing + model + clip/floor + screen residuals
seq_phys = S['blocks'].inv(rng.standard_normal((K, n)) * S['y_sd'][0] + S['y_mu'][0])  # physical-unit iterates
seq_flat = seq_phys.reshape(-1)
Pd = np.abs(rng.standard_normal(nb)) * 0.5; Qd = 0.3 * Pd
rc = bench(lambda: LI.predict(seq_flat, Pd, Qd), args.reps, args.warm)

print(f'\nGI-LSTM {LI.SYSTEM} {LI.OPF}: K={K}, state={n}, load inputs={n_load}, params={n_params:,}, '
      f'TF {tf.__version__}, threads={args.threads}, reps={args.reps}')
print(f'{"":42s}{"median":>9s}{"mean":>9s}{"min":>9s}{"p95":>9s}  [ms]')
for name, r in [('(a) forward pass, graph-compiled', ra),
                ('(b) forward pass, eager Keras call', rb),
                ('(c) full predict(): std + model + clip + screen', rc)]:
    print(f'{name:42s}{r["median"]:9.3f}{r["mean"]:9.3f}{r["min"]:9.3f}{r["p95"]:9.3f}')
print('\n(a) is the number to report as "GI-LSTM inference time"; (c) minus (a) is Python-side '
      'pre/post-processing; the MATLAB-measured infer_ms minus (c) is the MATLAB<->Python bridge cost.')
