%% timeing_periter.m -- wall time of each Newton iteration of classical MIPS 
%  Needs: MATPOWER already on the MATLAB path, and the instrumented mips.m in ROOT
%  (output.it_time / output.proj_time)
clear;
ROOT     = 'C:\Users\famani1\Desktop\Codes\R2_codes\LIPM';
casename = 'case2869pegase';  opf_type = 'acopf';
n_rep    = 5;                 % repeat the solve, report median per iteration

addpath(genpath('C:\matpower7.0'));  addpath(ROOT);  define_constants;   % MATPOWER first, LIPM in front of it
warning('off','MATLAB:nearlySingularMatrix'); warning('off','MATLAB:singularMatrix');
maxNumCompThreads(1);
if isappdata(0,'lipm'), rmappdata(0,'lipm'); end           % make sure the L-IPM hook is off
if exist('ipm_logger','file'), ipm_logger('disable'); end

mpc   = loadcase(casename);
mpopt = mpoption('verbose', 0, 'out.all', 0, 'opf.dc.solver', 'MIPS', 'opf.ac.solver', 'MIPS');
if strcmp(opf_type,'dcopf'), solver = @rundcopf; else, solver = @runopf; end

fprintf('warm-up solve ...\n');  solver(mpc, mpopt);       % not recorded

IT = []; TT = zeros(n_rep,1);
for q = 1:n_rep
    t0 = tic;  r = solver(mpc, mpopt);  TT(q) = toc(t0);
    o  = r.raw.output;
    if ~isfield(o, 'it_time')
        error('mips.m on the path has no it_time field -- edit the file reported by "which mips".');
    end
    IT(q, 1:o.iterations) = o.it_time(1:o.iterations)';   %#ok<SAGROW>
    fprintf('run %d: %d iterations, %.2f s\n', q, o.iterations, TT(q));
end
n_it  = size(IT, 2);
it_ms = 1e3 * median(IT, 1);                               % median over repetitions, per iteration

fprintf('\n%s %s : %d Newton iterations, total %.2f s (median of %d runs)\n', ...
    casename, upper(opf_type), n_it, median(TT), n_rep);
fprintf('iteration :'); fprintf(' %6d',  1:n_it);  fprintf('\n');
fprintf('time [ms] :'); fprintf(' %6.0f', it_ms);  fprintf('\n\n');
fprintf('first three iterations : %.0f, %.0f, %.0f ms\n', it_ms(1:3));
fprintf('last iteration         : %.0f ms\n', it_ms(end));
fprintf('mean +/- std per iter. : %.0f +/- %.0f ms\n', mean(it_ms), std(it_ms));
fprintf('outside Newton loop    : %.0f ms (setup + post-processing)\n', 1e3*median(TT) - sum(it_ms));
fprintf('iterations 4..%d (what the projection would skip): %.2f s\n', n_it, sum(it_ms(4:end))/1e3);

writematrix([(1:n_it)' it_ms'], fullfile(ROOT, sprintf('ipm_iter_timing_%s_%s.csv', casename, opf_type)));
