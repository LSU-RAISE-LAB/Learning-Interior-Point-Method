function export_case_data(casename, label, opf_type)
%EXPORT_CASE_DATA  Save network data + MIPS vector layout for the gi_lstm_*.py trainers
%
%   export_case_data('case3',           '3bus',  'dcopf')
%   export_case_data('case3',           '3bus',  'acopf')
%   export_case_data('case24_ieee_rts', '24bus', 'dcopf')
%   export_case_data('case24_ieee_rts', '24bus', 'acopf')
%   export_case_data('case118',         '118bus', 'dcopf')
%   export_case_data('case118',         '118bus', 'acopf')
%   export_case_data('case2869pegase',  '2869bus', 'dcopf')
%   export_case_data('case2869pegase',  '2869bus', 'acopf')
%
%   Writes <label>_<opf_type>_meta.mat in the current folder. Run it once per
%   system / OPF type, in the same folder as the data files.

define_constants;
mpc    = loadcase(casename);
Pd_ext = mpc.bus(:, PD);
Qd_ext = mpc.bus(:, QD);
load_idx = find(Pd_ext ~= 0);                 % same rule as Data_Generation.m

mpopt = mpoption('verbose', 0, 'out.all', 0, ...
                 'opf.dc.solver', 'MIPS', 'opf.ac.solver', 'MIPS');
is_dc = strcmpi(opf_type, 'dcopf');
if is_dc
    res = rundcopf(mpc, mpopt);
else
    res = runopf(mpc, mpopt);
end
if ~res.success, error('Nominal OPF did not converge for %s', casename); end
om = res.om;

%% internal (ext2int) case actually used by the solver
try
    mpci = om.get_mpc();
catch
    mpci = ext2int(mpc);
end
baseMVA = mpci.baseMVA;
bus = mpci.bus;  gen = mpci.gen;  branch = mpci.branch;
nb = size(bus, 1);  ng = size(gen, 1);  nl = size(branch, 1);

%% variable layout inside MIPS x
[vv, ~, ~, ~] = om.get_idx();
names = {'Va', 'Vm', 'Pg', 'Qg', 'y'};
idx = struct();
for k = 1:numel(names)
    if isfield(vv.i1, names{k})
        idx.(names{k}) = [vv.i1.(names{k}), vv.iN.(names{k})];   % 1-based inclusive
    end
end
nx = om.getN('var');

%% replicate MIPS's constraint split to get sizes of lam and mu (= z)
[~, xmin, xmax] = om.params_var();
try
    [A, l, u] = om.params_lin_constraint();
catch
    [A, l, u] = om.linear_constraints();
end
try nle = om.getN('nle'); catch, nle = 0; end
try nli = om.getN('nli'); catch, nli = 0; end
if isempty(A), A = sparse(0, nx); l = zeros(0,1); u = zeros(0,1); end
ll = [xmin; l];  uu = [xmax; u];
ieq = find( abs(uu-ll) <= eps );
igt = find( uu >=  1e10 & ll > -1e10 );
ilt = find( ll <= -1e10 & uu <  1e10 );
ibx = find( (abs(uu-ll) > eps) & (uu < 1e10) & (ll > -1e10) );
nlam = nle + numel(ieq);
nmu  = nli + numel(ilt) + numel(igt) + 2*numel(ibx);
fprintf('%s %s: nx=%d  nlam=%d  nmu=nz=%d  -> logged state length = %d\n', ...
        label, opf_type, nx, nlam, nmu, nx + nlam + 2*nmu);

%% branch admittances (as in makeYbus) and DC susceptances (as in makeBdc)
stat = branch(:, BR_STATUS);
Ys   = stat ./ (branch(:, BR_R) + 1j * branch(:, BR_X));
Bc   = stat .* branch(:, BR_B);
tap  = ones(nl, 1);
it   = find(branch(:, TAP));  tap(it) = branch(it, TAP);
tapc = tap .* exp(1j*pi/180 * branch(:, SHIFT));
Ytt  = Ys + 1j*Bc/2;
Yff  = Ytt ./ (tapc .* conj(tapc));
Yft  = -Ys ./ conj(tapc);
Ytf  = -Ys ./ tapc;
Ysh  = (bus(:, GS) + 1j * bus(:, BS)) / baseMVA;

b_dc     = stat ./ branch(:, BR_X) ./ tap;
Pfinj_dc = b_dc .* (-branch(:, SHIFT) * pi/180);

%% pack and save
M = struct();
M.casename = casename;  M.label = label;  M.opf_type = opf_type;
M.baseMVA = baseMVA;  M.nb = nb;  M.ng = ng;  M.nl = nl;
M.nx = nx;  M.nlam = nlam;  M.nmu = nmu;  M.nz = nmu;
M.idx = idx;
% loads: external (for alpha) and mapping to internal bus order
M.Pd_ext = Pd_ext;  M.Qd_ext = Qd_ext;  M.load_idx = load_idx;
M.bus_on = mpci.order.bus.status.on(:);     % external rows kept, in internal order
% bus data (internal order)
M.Vmin = bus(:, VMIN);  M.Vmax = bus(:, VMAX);
M.Gs = bus(:, GS);      M.Bs = bus(:, BS);
M.Ysh_re = real(Ysh);   M.Ysh_im = imag(Ysh);
% generators (internal order = MIPS Pg/Qg order)
M.gen_bus = gen(:, GEN_BUS);
M.Pmin = gen(:, PMIN);  M.Pmax = gen(:, PMAX);
M.Qmin = gen(:, QMIN);  M.Qmax = gen(:, QMAX);
% branches
M.f = branch(:, F_BUS);  M.t = branch(:, T_BUS);  M.rate_a = branch(:, RATE_A);
M.Yff_re = real(Yff); M.Yff_im = imag(Yff);
M.Yft_re = real(Yft); M.Yft_im = imag(Yft);
M.Ytf_re = real(Ytf); M.Ytf_im = imag(Ytf);
M.Ytt_re = real(Ytt); M.Ytt_im = imag(Ytt);
M.b_dc = b_dc;  M.Pfinj_dc = Pfinj_dc;

outname = sprintf('%s_%s_meta.mat', label, opf_type);
save(outname, '-struct', 'M', '-v7');
fprintf('saved %s\n', outname);
end
