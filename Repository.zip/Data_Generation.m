%% Data_Generation.m
%  Generates IPM central-path training data (first `keep` iterations + final)
%  for DC and AC OPF on several MATPOWER cases using Latin hypercube load sampling.
%
%  Output files (in the current folder):
%    3bus_dcopf.xlsx, 3bus_acopf.xlsx, 24bus_dcopf.xlsx, 24bus_acopf.xlsx
%    118bus_dcopf_partNN.mat,  118bus_acopf_partNN.mat
%    2869bus_dcopf_partNN.mat, 2869bus_acopf_partNN.mat
%
%  Requires: MATPOWER on the path, your edited mips.m (with the ipm_logger('log',...)
%  call) shadowing the installed one, and ipm_logger.m in this folder.
%
%  NOTE: the 2869-bus scenarios use the 'narrow' load ranges; the L-IPM scripts
%  (LIPM_run.m, LIPM_once.m, LIPM_timing.m) must rebuild scenarios with the same
%  ranges and the same kmax as listed in the table below.

clear; define_constants;
warning('off', 'MATLAB:nearlySingularMatrix');
warning('off', 'MATLAB:singularMatrix');
warning('off', 'MATLAB:illConditionedMatrix');

%% ---------------- configuration ----------------
wide   = {[0.8 0.9],  [1.1 1.2],  [0.8 1.2], [0.9 1.1]};    % low, high, mixed, nominal
narrow = {[0.9 0.95], [1.05 1.1], [0.9 1.1], [0.95 1.05]};

%          case file            label      kmax  keep  file ext  load ranges
cases = { 'case3',              '3bus',    1000, 5,    '.xlsx',  wide;    % case3.m ships with this repository
          'case24_ieee_rts',    '24bus',   1000, 5,    '.xlsx',  wide;
          'case118',            '118bus',  2000, 5,    '.mat',   wide;
          'case2869pegase',     '2869bus', 5000, 4,    '.mat',   narrow };

opf_types   = {'dcopf', 'acopf'};
flush_every = 250;

%% ---------------- main loop ----------------
for c = 1:size(cases, 1)
        [casename, label, kmax, keep, ext, ranges] = cases{c, :};
    mpc0     = loadcase(casename);
    load_idx = find(mpc0.bus(:, PD) ~= 0);
    n_d      = numel(load_idx);

    for t = 1:numel(opf_types)
        opf_type = opf_types{t};
        outfile  = sprintf('%s_%s%s', label, opf_type, ext);
        fprintf('\n===== %s  %s  (%d runs, n_d = %d) =====\n', casename, opf_type, kmax, n_d);

        rng(42);
        U = lhsdesign(kmax, n_d);
        if strcmp(opf_type, 'dcopf')
            mpopt  = mpoption('verbose', 0, 'out.all', 0, 'opf.dc.solver', 'MIPS');
            solver = @rundcopf;
        else
            mpopt  = mpoption('verbose', 0, 'out.all', 0, 'opf.ac.solver', 'MIPS');
            solver = @runopf;
        end

        ipm_logger('init', outfile, keep);
        t0 = tic;
        for k = 1:kmax
            r     = ranges{mod(k-1, 4) + 1};
            alpha = r(1) + (r(2) - r(1)) * U(k, :)';
            mpc   = mpc0;
            mpc.bus(load_idx, PD) = mpc0.bus(load_idx, PD) .* alpha;
            mpc.bus(load_idx, QD) = mpc0.bus(load_idx, QD) .* alpha;

            ipm_logger('new_run', k, alpha);
            try
                res = solver(mpc, mpopt);
                ipm_logger('end_run', res.success, res.raw.output.iterations, res.f);
            catch ME
                ipm_logger('end_run', 0, NaN, NaN);
                fprintf('run %d failed: %s\n', k, ME.message);
            end

            if mod(k, flush_every) == 0
                ipm_logger('flush');
                fprintf('  %d/%d done, %.1f min elapsed\n', k, kmax, toc(t0)/60);
            end
        end
        if mod(kmax, flush_every) ~= 0      % write the remaining scenarios
            ipm_logger('flush');
        end
        fprintf('%s finished in %.1f min\n', outfile, toc(t0)/60);
    end
end

warning('on', 'MATLAB:nearlySingularMatrix');
warning('on', 'MATLAB:singularMatrix');
warning('on', 'MATLAB:illConditionedMatrix');
