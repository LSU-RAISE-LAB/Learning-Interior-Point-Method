%% IPM_vs_LIPM_24bus.m -- classical IPM vs L-IPM (GI-LSTM projection after K iterations) 
%  3-bus DCOPF test scenarios (the GI-LSTM test split saved by gi_lstm_24bus_acopf.py)
%  Requires on the MATLAB path: MATPOWER, your edited mips.m (with the L-IPM hook),
%  ipm_logger.m (with the 'get_run' command), lipm_project.m, case3.m.
%  Requires in DATA_DIR: 3bus_dcopf_meta.mat, gilstm_24bus_dcopf\..., lipm_infer.py,
%  gi_lstm_24bus_acopf.py.
%  lipm_project.m, lipm_infer.py, <label>_<opf>_meta.mat, gilstm_<label>_<opf>\).

clear;
PY_EXE   = getenv('LIPM_PYTHON');            % python.exe of the 'lipm' conda env,
if isempty(PY_EXE), PY_EXE = 'python'; end   %  e.g. C:\Users\<you>\Anaconda3\envs\lipm\python.exe
casename = 'case24_ieee_rts';  label = '24bus';  opf_type = 'acopf';
K  = 3; tol_ineq = 1e-3; kmax = 1000; e_n = 205; tol_bal = 0.4;
ROOT     = fileparts(mfilename('fullpath'));  % folder containing this script
DATA_DIR = ROOT;

restoredefaultpath;
if isfolder(fullfile(ROOT, 'mips', 'lib')), mipsdir = fullfile(ROOT, 'mips', 'lib');
else,                                       mipsdir = fullfile(ROOT, 'mips'); end
addpath(fullfile(ROOT, 'lib'), mipsdir);
addpath(ROOT);                 % last: the hooked mips.m in ROOT shadows the library copy
define_constants;
warning('off', 'MATLAB:nearlySingularMatrix'); warning('off', 'MATLAB:singularMatrix');
maxNumCompThreads(1);

%% ---- Python bridge (once per MATLAB session) ----
pe = pyenv;
if pe.Status == "NotLoaded"
    pyenv('Version', PY_EXE, 'ExecutionMode', 'OutOfProcess');
end
if count(py.sys.path, DATA_DIR) == 0, insert(py.sys.path, int32(0), DATA_DIR); end
py.importlib.import_module('lipm_infer');
py.lipm_infer.warmup();

%% ---- build the scenario ----
M        = load(fullfile(DATA_DIR, sprintf('%s_%s_meta.mat', label, opf_type)));
mpc0     = loadcase(casename);
load_idx = find(mpc0.bus(:, PD) ~= 0);  n_d = numel(load_idx);
if isempty(e_n)
    alpha = ones(n_d, 1);  k = 0;
else
    rng(42);  U = lhsdesign(kmax, n_d);        % identical design to Data_Generation.m
    ranges = {[0.8 0.9], [1.1 1.2], [0.8 1.2], [0.9 1.1]};
    r = ranges{mod(e_n-1, 4) + 1};
    alpha = r(1) + (r(2) - r(1)) * U(e_n, :)';  k = e_n;
end
mpc = mpc0;
mpc.bus(load_idx, PD) = mpc0.bus(load_idx, PD) .* alpha;
mpc.bus(load_idx, QD) = mpc0.bus(load_idx, QD) .* alpha;
a_full = ones(size(mpc0.bus, 1), 1);  a_full(load_idx) = alpha;
on = M.bus_on(:);
Pd = mpc0.bus(:, PD) .* a_full;  Pd = Pd(on) / M.baseMVA;
Qd = mpc0.bus(:, QD) .* a_full;  Qd = Qd(on) / M.baseMVA;

mpopt = mpoption('verbose', 0, 'out.all', 0, 'opf.dc.solver', 'MIPS', 'opf.ac.solver', 'MIPS');
if strcmp(opf_type, 'dcopf'), solver = @rundcopf; else, solver = @runopf; end

%% ---- classical IPM ----
if isappdata(0, 'lipm'), rmappdata(0, 'lipm'); end
ipm_logger('disable');
solver(mpc, mpopt);                                        % warm-up (JIT), not timed
t0 = tic;  r1 = solver(mpc, mpopt);  t_ipm = toc(t0);

%% ---- L-IPM ----
ipm_logger('init', fullfile(DATA_DIR, 'lipm_tmp.xlsx'), Inf);
ipm_logger('new_run', k, alpha);
setappdata(0, 'lipm', struct('K', K, 'Pd', Pd, 'Qd', Qd, ...
    'nx', M.nx, 'nlam', M.nlam, 'nmu', M.nmu, 'tol_ineq', tol_ineq, 'tol_bal', tol_bal, ...
    'applied', false, 'infer_time', NaN, 'max_ineq', NaN, 'max_bal', NaN));
t0 = tic;  r2 = solver(mpc, mpopt);  t_lipm = toc(t0);
S = getappdata(0, 'lipm');  rmappdata(0, 'lipm');
fprintf('  classical IPM iteration count: %d iterations\n', r1.raw.output.iterations);
fprintf('  L-IPM iteration count      : %d iterations\n', r2.raw.output.iterations);