"""
lipm_infer.py  --  GI-LSTM inference bridge called from MATLAB (lipm_project.m).

Loads the trained model once (first import), then `predict()` maps the first K
IPM iterates + scenario load to the projected final state [x; lam; mu; z] in
physical units, after hard clipping of P_G / V_m and flooring of mu, z.

MATLAB usage (see LIPM_run.m):
    insert(py.sys.path, int32(0), DATA_DIR);
    py.importlib.import_module('lipm_infer');  py.lipm_infer.warmup();
    res = py.lipm_infer.predict(seq_flat, Pd, Qd);   % -> (y_clip, max_ineq, max_bal)
"""
import os, json
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
from array import array
import numpy as np
import tensorflow as tf

# ---------------------------------------------------------------- settings ----
DATA_DIR   = r'C:\Users\famani1\Desktop\R2_LIPM'
SYSTEM     = '24bus'
OPF        = 'acopf'
MODEL_FILE = 'gi_lstm_24bus_acopf'      # python module holding GILSTM / GridPhysics / Blocks
MU_Z_FLOOR = 1e-8                      # IPM needs strictly positive mu and z
# ------------------------------------------------------------------------------

import importlib, sys
if DATA_DIR not in sys.path:
    sys.path.insert(0, DATA_DIR)
G = importlib.import_module(MODEL_FILE)

_S = {}          # loaded state (model, scalers, physics)


def _load():
    if _S:
        return _S
    tag = f'{SYSTEM}_{OPF}'
    out_dir = os.path.join(DATA_DIR, f'gilstm_{tag}')
    meta = G.load_meta(os.path.join(DATA_DIR, f'{tag}_meta.mat'))
    with open(os.path.join(out_dir, 'results.json')) as f:
        res = json.load(f)
    K      = int(res.get('K', 3))
    hidden = int(res.get('hidden', 128))
    layers = int(res.get('layers', 2))
    sc = np.load(os.path.join(out_dir, 'scalers.npz'))
    is_dc = OPF == 'dcopf'
    phys = G.GridPhysics(meta, is_dc)
    blocks = G.Blocks(meta)
    n_state = blocks.n
    n_load = int(sc['l_mu'].shape[1])
    model = G.GILSTM(K, n_state, hidden, layers, 0.0, 0.0, phys,
                     sc['y_mu'][0], sc['y_sd'][0], (1.0, 1.0, 1.0, 1.0), name='GI_LSTM')
    model((np.zeros((1, K, n_state), np.float32), np.zeros((1, n_load), np.float32)))
    model.load_weights(os.path.join(out_dir, 'gi_lstm.weights.h5'))
    _S.update(dict(K=K, n_state=n_state, n_load=n_load, is_dc=is_dc, phys=phys, blocks=blocks,
                   model=model, x_mu=sc['x_mu'], x_sd=sc['x_sd'], l_mu=sc['l_mu'], l_sd=sc['l_sd'],
                   y_mu=sc['y_mu'], y_sd=sc['y_sd'], nb=meta['nb']))
    print(f'lipm_infer: loaded {tag} (K={K}, hidden={hidden}, layers={layers}, state={n_state})')
    return _S


def warmup():
    """Load model and run one dummy prediction so the first real call is fast."""
    S = _load()
    predict(np.zeros(S['K'] * S['n_state']), np.zeros(S['nb']), np.zeros(S['nb']))
    return True


def predict(seq_flat, Pd, Qd):
    """
    seq_flat : first K logged iterates, row-major flattened (K * n_state values)
    Pd, Qd   : scenario load, internal bus order, p.u.  (Qd ignored for DCOPF)
    returns  : (y_clip as array('d'), max normalized inequality residual, max |balance| residual p.u.)
    """
    S = _load()
    K, n = S['K'], S['n_state']
    seq = np.asarray(seq_flat, np.float64).reshape(K, n)
    Pd = np.asarray(Pd, np.float32).reshape(1, -1)
    Qd = np.asarray(Qd, np.float32).reshape(1, -1)
    load = Pd if S['is_dc'] else np.concatenate([Pd, Qd], axis=1)

    # ---- model space: log(mu,z) then standardize with training statistics ----
    seq_m = S['blocks'].fwd(seq.copy())
    Xs = ((seq_m - S['x_mu']) / S['x_sd']).astype(np.float32)[None, ...]
    Ls = ((load - S['l_mu']) / S['l_sd']).astype(np.float32)

    yp_std = S['model']((Xs, Ls), training=False).numpy()
    yp = S['blocks'].inv(yp_std * S['y_sd'] + S['y_mu'])            # physical units, (1, n)

    # ---- hard projection (eqs. 15-16) and interior floor for mu, z ----
    yc = S['phys'].clip(yp)
    yc[:, S['blocks'].mu] = np.maximum(yc[:, S['blocks'].mu], MU_Z_FLOOR)
    yc[:, S['blocks'].z]  = np.maximum(yc[:, S['blocks'].z],  MU_Z_FLOOR)

    # ---- acceptability screen quantities ----
    ineq, bal = S['phys'].residuals(tf.constant(yc, tf.float32), tf.constant(Pd), tf.constant(Qd))
    max_ineq = float(np.maximum(ineq.numpy(), 0.0).max())
    max_bal  = float(np.abs(bal.numpy()).max())
    return array('d', yc[0].astype(np.float64).tolist()), max_ineq, max_bal