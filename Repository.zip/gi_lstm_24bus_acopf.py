"""
gi_lstm.py  --  Grid-Informed LSTM (GI-LSTM) for IPM central-path projection.

  * input : first K IPM iterates  [x; lam; mu; z]  + scenario load vector
  * output: final converged iterate [x; lam; mu; z]
  * model : stacked LSTM -> fully connected; dropout + L2
  * loss  : w1*mean(P_G err^2) + w2*mean(V_m or theta err^2)
            + w3*( mean [rho_ineq]_+^2 + mean rho_bal^2 )
            + w4*mean(standardized full-vector err^2)
  * mu, z are log-transformed before standardization (they are strictly
    positive IPM quantities spanning several orders of magnitude)
  * post  : hard clipping of P_G / Q_G / V_m (eqs. 15-16) + acceptability screen

Usage:   python gi_lstm.py --system 3bus --opf dcopf
Install: pip install "tensorflow==2.13.*" pandas openpyxl scipy h5py matplotlib   (Python 3.8)
         pip install "tensorflow>=2.16"   pandas openpyxl scipy h5py matplotlib   (Python 3.9-3.12)
"""

import argparse, glob, json, os, time
import numpy as np
import pandas as pd
import scipy.io as sio
import tensorflow as tf
from tensorflow import keras

N_HIST = 11          # run_id + 10 History scalars precede the state vector
LOG_EPS = 1e-6      # floor before log-transforming mu and z


# ----------------------------------------------------------------------------
# 1. Data loading
# ----------------------------------------------------------------------------
def load_meta(path):
    m = sio.loadmat(path, squeeze_me=True, struct_as_record=False)
    m = {k: v for k, v in m.items() if not k.startswith('__')}
    idx = {}
    for name in ('Va', 'Vm', 'Pg', 'Qg', 'y'):
        if hasattr(m['idx'], name):
            i1, iN = np.atleast_1d(getattr(m['idx'], name)).astype(int)
            idx[name] = slice(i1 - 1, iN)
    m['idx'] = idx
    for k in ('nx', 'nlam', 'nmu', 'nz', 'nb', 'ng', 'nl'):
        m[k] = int(m[k])
    m['baseMVA'] = float(m['baseMVA'])
    return m


def load_history(system, opf, data_dir):
    xlsx = os.path.join(data_dir, f'{system}_{opf}.xlsx')
    parts = sorted(glob.glob(os.path.join(data_dir, f'{system}_{opf}_part*.mat')))
    if os.path.exists(xlsx):
        H = pd.read_excel(xlsx, sheet_name='History').to_numpy(dtype=np.float64)
        S = pd.read_excel(xlsx, sheet_name='Summary').to_numpy(dtype=np.float64)
    elif parts:
        import h5py
        Hs = []
        for p in parts:
            with h5py.File(p, 'r') as f:
                Hs.append(np.array(f['H']).T.astype(np.float64))
                S = np.array(f['S']).T.astype(np.float64)
        H = np.concatenate(Hs, axis=0)
    else:
        raise FileNotFoundError(f'no {xlsx} or {system}_{opf}_part*.mat in {data_dir}')
    return H, S


def build_sequences(H, S, meta, K):
    n_state = meta['nx'] + meta['nlam'] + 2 * meta['nmu']
    if H.shape[1] - N_HIST != n_state:
        raise ValueError(f'state length in data = {H.shape[1]-N_HIST}, meta says {n_state}. '
                         f'Check mips.m logs [x; lam; mu; z] and export_case_data.m ran on the '
                         f'same MATPOWER version.')
    run_ok = {int(r[0]): r for r in S if r[1] == 1}
    X, Y, RID, ALPHA = [], [], [], []
    for rid in np.unique(H[:, 0]).astype(int):
        if rid not in run_ok:
            continue
        rows = H[H[:, 0] == rid]
        rows = rows[np.argsort(rows[:, 5])]
        iters = rows[:, 5].astype(int)
        if iters.max() <= K or not np.all(np.isin(np.arange(1, K + 1), iters)):
            continue
        X.append(np.stack([rows[iters == k][0, N_HIST:] for k in range(1, K + 1)]))
        Y.append(rows[-1, N_HIST:])
        RID.append(rid); ALPHA.append(run_ok[rid][4:])
    return (np.asarray(X, np.float64), np.asarray(Y, np.float64),
            np.asarray(RID), np.asarray(ALPHA, np.float64))


def scenario_loads(alpha, meta):
    Pd_ext = np.atleast_1d(meta['Pd_ext']).astype(float)
    Qd_ext = np.atleast_1d(meta['Qd_ext']).astype(float)
    load_idx = np.atleast_1d(meta['load_idx']).astype(int) - 1
    on = np.atleast_1d(meta['bus_on']).astype(int) - 1
    a_full = np.ones((alpha.shape[0], Pd_ext.size))
    a_full[:, load_idx] = alpha
    Pd = (a_full * Pd_ext)[:, on] / meta['baseMVA']
    Qd = (a_full * Qd_ext)[:, on] / meta['baseMVA']
    return Pd.astype(np.float32), Qd.astype(np.float32)


def split_indices(rid, seed, frac=(0.8, 0.1, 0.1)):
    rng = np.random.default_rng(seed)
    cond = (rid - 1) % 4
    tr, va, te = [], [], []
    for c in range(4):
        ids = np.where(cond == c)[0]; rng.shuffle(ids)
        n = len(ids); n_tr = int(frac[0] * n); n_va = int(frac[1] * n)
        tr += list(ids[:n_tr]); va += list(ids[n_tr:n_tr + n_va]); te += list(ids[n_tr + n_va:])
    return np.array(tr), np.array(va), np.array(te)


# ---- block structure of the state vector and mu/z log transform -------------
class Blocks:
    def __init__(self, meta):
        nx, nlam, nmu = meta['nx'], meta['nlam'], meta['nmu']
        self.x = slice(0, nx)
        self.lam = slice(nx, nx + nlam)
        self.mu = slice(nx + nlam, nx + nlam + nmu)
        self.z = slice(nx + nlam + nmu, nx + nlam + 2 * nmu)
        self.n = nx + nlam + 2 * nmu

    def fwd(self, v):            # physical -> model space (log on mu, z)
        v = v.copy()
        for s in (self.mu, self.z):
            v[..., s] = np.log(np.maximum(v[..., s], LOG_EPS))
        return v

    def inv(self, v):
        v = v.copy()
        for s in (self.mu, self.z):
            v[..., s] = np.exp(v[..., s])
        return v


class Scaler:
    def __init__(self, data, axis, rel_floor=1e-2):
        self.mu = data.mean(axis=axis, keepdims=True).astype(np.float32)
        sd = data.std(axis=axis, keepdims=True).astype(np.float32)
        floor = max(rel_floor * float(np.median(sd)), 1e-6)
        sd = np.maximum(sd, floor)                # avoid amplifying near-constant columns
        self.sd = sd
    def fwd(self, x): return ((x - self.mu) / self.sd).astype(np.float32)
    def inv(self, x): return x * self.sd + self.mu


# ----------------------------------------------------------------------------
# 2. Grid physics
# ----------------------------------------------------------------------------
class GridPhysics:
    def __init__(self, meta, is_dc):
        f32 = lambda v: tf.constant(np.atleast_1d(v).astype(np.float32))
        i32 = lambda v: tf.constant(np.atleast_1d(v).astype(np.int32))
        b = meta['baseMVA']
        self.is_dc = is_dc
        self.nb, self.ng, self.nl = meta['nb'], meta['ng'], meta['nl']
        self.idx = meta['idx']
        self.f = i32(np.atleast_1d(meta['f']) - 1); self.t = i32(np.atleast_1d(meta['t']) - 1)
        self.gen_bus = i32(np.atleast_1d(meta['gen_bus']) - 1)
        self.Pmin = f32(meta['Pmin']) / b; self.Pmax = f32(meta['Pmax']) / b
        self.Qmin = f32(meta['Qmin']) / b; self.Qmax = f32(meta['Qmax']) / b
        self.Vmin = f32(meta['Vmin']);      self.Vmax = f32(meta['Vmax'])
        self.Prange = tf.maximum(self.Pmax - self.Pmin, 1e-3)
        self.Qrange = tf.maximum(self.Qmax - self.Qmin, 1e-3)
        self.Vrange = tf.maximum(self.Vmax - self.Vmin, 1e-3)
        rate = np.atleast_1d(meta['rate_a']).astype(np.float32)
        self.has_lim = f32((rate > 0) & (rate < 1e9))
        self.F = f32(np.where(rate > 0, rate, 1.0)) / b
        self.Gs = f32(meta['Gs']) / b
        for k in ('Yff', 'Yft', 'Ytf', 'Ytt', 'Ysh'):
            setattr(self, k + '_re', f32(meta[k + '_re'])); setattr(self, k + '_im', f32(meta[k + '_im']))
        self.b_dc = f32(meta['b_dc']); self.Pfinj = f32(meta['Pfinj_dc'])

    def _seg(self, vals, ids, n):
        return tf.transpose(tf.math.unsorted_segment_sum(tf.transpose(vals), ids, n))
    def _gather(self, v, ids):
        return tf.gather(v, ids, axis=1)

    def residuals(self, y, Pd, Qd):
        """y: (batch, n_state) in PHYSICAL units. -> (ineq, bal)"""
        Va = y[:, self.idx['Va']]; Pg = y[:, self.idx['Pg']]
        Pg_bus = self._seg(Pg, self.gen_bus, self.nb)
        ineq = [(Pg - self.Pmax) / self.Prange, (self.Pmin - Pg) / self.Prange]
        if self.is_dc:
            Pf = self.b_dc * (self._gather(Va, self.f) - self._gather(Va, self.t)) + self.Pfinj
            Pbus = self._seg(Pf, self.f, self.nb) - self._seg(Pf, self.t, self.nb)
            bal = Pbus + Pd + self.Gs - Pg_bus
            ineq.append(self.has_lim * (tf.abs(Pf) - self.F) / self.F)
            return tf.concat(ineq, axis=1), bal

        Vm = y[:, self.idx['Vm']]; Qg = y[:, self.idx['Qg']]
        Qg_bus = self._seg(Qg, self.gen_bus, self.nb)
        Vr, Vi = Vm * tf.cos(Va), Vm * tf.sin(Va)
        Vfr, Vfi = self._gather(Vr, self.f), self._gather(Vi, self.f)
        Vtr, Vti = self._gather(Vr, self.t), self._gather(Vi, self.t)
        cm = lambda ar, ai, br, bi: (ar * br - ai * bi, ar * bi + ai * br)
        a = cm(self.Yff_re, self.Yff_im, Vfr, Vfi); c = cm(self.Yft_re, self.Yft_im, Vtr, Vti)
        Ifr, Ifi = a[0] + c[0], a[1] + c[1]
        a = cm(self.Ytf_re, self.Ytf_im, Vfr, Vfi); c = cm(self.Ytt_re, self.Ytt_im, Vtr, Vti)
        Itr, Iti = a[0] + c[0], a[1] + c[1]
        Ibr = self._seg(Ifr, self.f, self.nb) + self._seg(Itr, self.t, self.nb) + self.Ysh_re * Vr - self.Ysh_im * Vi
        Ibi = self._seg(Ifi, self.f, self.nb) + self._seg(Iti, self.t, self.nb) + self.Ysh_re * Vi + self.Ysh_im * Vr
        Pcalc = Vr * Ibr + Vi * Ibi; Qcalc = Vi * Ibr - Vr * Ibi
        bal = tf.concat([Pcalc + Pd - Pg_bus, Qcalc + Qd - Qg_bus], axis=1)
        Sf = tf.sqrt((Vfr * Ifr + Vfi * Ifi) ** 2 + (Vfi * Ifr - Vfr * Ifi) ** 2 + 1e-12)
        St = tf.sqrt((Vtr * Itr + Vti * Iti) ** 2 + (Vti * Itr - Vtr * Iti) ** 2 + 1e-12)
        ineq += [(Qg - self.Qmax) / self.Qrange, (self.Qmin - Qg) / self.Qrange,
                 (Vm - self.Vmax) / self.Vrange, (self.Vmin - Vm) / self.Vrange,
                 self.has_lim * (Sf - self.F) / self.F, self.has_lim * (St - self.F) / self.F]
        return tf.concat(ineq, axis=1), bal

    def clip(self, y):
        y = y.copy()
        y[:, self.idx['Pg']] = np.clip(y[:, self.idx['Pg']], self.Pmin.numpy(), self.Pmax.numpy())
        if not self.is_dc:
            y[:, self.idx['Vm']] = np.clip(y[:, self.idx['Vm']], self.Vmin.numpy(), self.Vmax.numpy())
            y[:, self.idx['Qg']] = np.clip(y[:, self.idx['Qg']], self.Qmin.numpy(), self.Qmax.numpy())
        return y


# ----------------------------------------------------------------------------
# 3. Model
# ----------------------------------------------------------------------------
class GILSTM(keras.Model):
    def __init__(self, K, n_state, hidden, n_layers, dropout, l2, physics,
                 y_mu, y_sd, w, **kw):
        super().__init__(**kw)
        reg = keras.regularizers.l2(l2) if l2 > 0 else None
        self.K = K
        self.lstms = [keras.layers.LSTM(hidden, return_sequences=(i < n_layers - 1),
                                        dropout=dropout, kernel_regularizer=reg,
                                        recurrent_regularizer=reg, name=f'lstm_{i+1}')
                      for i in range(n_layers)]
        self.drop = keras.layers.Dropout(dropout)
        self.out = keras.layers.Dense(n_state, kernel_regularizer=reg, name='fc_out')
        self.physics = physics
        self.y_mu = tf.constant(y_mu); self.y_sd = tf.constant(y_sd)
        self.nx = physics.idx['Pg'].stop if False else None  # placeholder (unused)
        self.w = w
        self.trk = {k: keras.metrics.Mean(name=k) for k in
                    ('loss', 'l_pg', 'l_v', 'l_ineq', 'l_bal', 'l_full')}

    def call(self, inputs, training=False):
        seq, load_std = inputs[0], inputs[1]
        h = tf.concat([seq, tf.repeat(load_std[:, None, :], self.K, axis=1)], axis=-1)
        for lstm in self.lstms:
            h = lstm(h, training=training)
        return self.out(self.drop(h, training=training))

    def gi_loss(self, y_std, yp_std, Pd, Qd):
        # primal block is untransformed, so un-standardizing gives physical units for it
        y = y_std * self.y_sd + self.y_mu; yp = yp_std * self.y_sd + self.y_mu
        idx = self.physics.idx
        l_pg = tf.reduce_mean(tf.square(yp[:, idx['Pg']] - y[:, idx['Pg']]))
        key = 'Va' if self.physics.is_dc else 'Vm'
        l_v = tf.reduce_mean(tf.square(yp[:, idx[key]] - y[:, idx[key]]))
        ineq, bal = self.physics.residuals(yp, Pd, Qd)
        l_ineq = tf.reduce_mean(tf.square(tf.nn.relu(ineq)))
        l_bal = tf.reduce_mean(tf.square(bal))
        l_full = tf.reduce_mean(tf.square(yp_std - y_std))
        w = self.w
        total = w[0] * l_pg + w[1] * l_v + w[2] * (l_ineq + l_bal) + w[3] * l_full
        return total, dict(l_pg=l_pg, l_v=l_v, l_ineq=l_ineq, l_bal=l_bal, l_full=l_full)

    def _step(self, data, training):
        (seq, load_std, Pd, Qd), y = data
        if training:
            with tf.GradientTape() as tape:
                yp = self((seq, load_std), training=True)
                loss, parts = self.gi_loss(y, yp, Pd, Qd)
                if self.losses: loss = loss + tf.add_n(self.losses)
            grads = tape.gradient(loss, self.trainable_variables)
            self.optimizer.apply_gradients(zip(grads, self.trainable_variables))
        else:
            yp = self((seq, load_std), training=False)
            loss, parts = self.gi_loss(y, yp, Pd, Qd)
        self.trk['loss'].update_state(loss)
        for k, v in parts.items(): self.trk[k].update_state(v)
        return {k: m.result() for k, m in self.trk.items()}

    def train_step(self, data): return self._step(data, True)
    def test_step(self, data):  return self._step(data, False)
    @property
    def metrics(self): return list(self.trk.values())


# ----------------------------------------------------------------------------
# 4. Evaluation helpers
# ----------------------------------------------------------------------------
def r2_score(y, yp):
    ss_res = ((y - yp) ** 2).sum(); ss_tot = ((y - y.mean(0)) ** 2).sum()
    return float(1.0 - ss_res / max(ss_tot, 1e-12))


def residual_stats(phys, y_phys, Pd, Qd):
    ineq, bal = phys.residuals(tf.constant(y_phys, tf.float32), tf.constant(Pd), tf.constant(Qd))
    return np.maximum(ineq.numpy(), 0).max(1), np.abs(bal.numpy()).max(1)


# ----------------------------------------------------------------------------
# 5. Main
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--system', default='24bus', help='3bus | 24bus | 118bus | 2869bus')
    ap.add_argument('--opf', default='acopf', choices=['dcopf', 'acopf'])
    ap.add_argument('--data_dir', default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument('--K', type=int, default=3)
    ap.add_argument('--hidden', type=int, default=128)
    ap.add_argument('--layers', type=int, default=2)
    ap.add_argument('--dropout', type=float, default=0.2)
    ap.add_argument('--l2', type=float, default=1e-5)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--epochs', type=int, default=300)
    ap.add_argument('--batch', type=int, default=32)
    ap.add_argument('--patience', type=int, default=30)
    ap.add_argument('--w1', type=float, default=1.0)
    ap.add_argument('--w2', type=float, default=1.0)
    ap.add_argument('--w3', type=float, default=1.0)
    ap.add_argument('--w4', type=float, default=1.0)
    ap.add_argument('--tol_ineq', type=float, default=1e-3, help='normalized inequality tolerance')
    ap.add_argument('--tol_bal', type=float, default=5e-2, help='balance tolerance, p.u. (0.05 = 5 MW)')
    ap.add_argument('--seed', type=int, default=0)
    args = ap.parse_args()

    np.random.seed(args.seed); tf.random.set_seed(args.seed)
    tag = f'{args.system}_{args.opf}'
    out_dir = os.path.join(args.data_dir, f'gilstm_{tag}_w3{args.w3:g}_s{args.seed}'); os.makedirs(out_dir, exist_ok=True)
    is_dc = args.opf == 'dcopf'

    # ---- data ----
    meta = load_meta(os.path.join(args.data_dir, f'{tag}_meta.mat'))
    blocks = Blocks(meta)
    H, S = load_history(args.system, args.opf, args.data_dir)
    X, Y, rid, alpha = build_sequences(H, S, meta, args.K)
    Pd, Qd = scenario_loads(alpha, meta)
    load_vec = Pd if is_dc else np.concatenate([Pd, Qd], axis=1)
    print(f'{tag}: {len(rid)} converged scenarios, K={args.K}, state dim={Y.shape[1]} '
          f'(nx={meta["nx"]}, nlam={meta["nlam"]}, nmu=nz={meta["nmu"]}), load dim={load_vec.shape[1]}')

    tr, va, te = split_indices(rid, args.seed)
    Xm, Ym = blocks.fwd(X), blocks.fwd(Y)                      # log on mu, z
    xs = Scaler(Xm[tr].reshape(-1, Xm.shape[-1]), axis=0)
    ls = Scaler(load_vec[tr], axis=0)
    ys = Scaler(Ym[tr], axis=0)
    Xs, Ls, Ys = xs.fwd(Xm), ls.fwd(load_vec), ys.fwd(Ym)

    def ds(ix, shuffle):
        d = tf.data.Dataset.from_tensor_slices(((Xs[ix], Ls[ix], Pd[ix], Qd[ix]), Ys[ix]))
        if shuffle: d = d.shuffle(len(ix), seed=args.seed)
        return d.batch(args.batch)
    d_tr, d_va, d_te = ds(tr, True), ds(va, False), ds(te, False)

    # ---- model ----
    phys = GridPhysics(meta, is_dc)
    model = GILSTM(args.K, Y.shape[1], args.hidden, args.layers, args.dropout, args.l2, phys,
                   ys.mu[0], ys.sd[0], (args.w1, args.w2, args.w3, args.w4), name='GI_LSTM')
    model.compile(optimizer=keras.optimizers.Adam(args.lr))
    model((Xs[:2], Ls[:2])); model.summary()

    cbs = [keras.callbacks.EarlyStopping('val_loss', patience=args.patience, restore_best_weights=True),
           keras.callbacks.ReduceLROnPlateau('val_loss', factor=0.5, patience=10, min_lr=1e-6),
           keras.callbacks.CSVLogger(os.path.join(out_dir, 'train_log.csv'))]
    t0 = time.time()
    hist = model.fit(d_tr, validation_data=d_va, epochs=args.epochs, callbacks=cbs, verbose=2)
    train_min = (time.time() - t0) / 60

    # ---- evaluation ----
    t0 = time.time()
    Yp_std = model.predict(d_te, verbose=0)
    infer_ms = (time.time() - t0) / len(te) * 1e3
    Yp = blocks.inv(ys.inv(Yp_std))                            # back to physical units
    Yt = Y[te]; Yts = Ys[te]
    idx = meta['idx']; b = meta['baseMVA']
    B = blocks
    res = {
        'n_train': int(len(tr)), 'n_val': int(len(va)), 'n_test': int(len(te)),
        'epochs_run': len(hist.history['loss']), 'train_time_min': train_min,
        'inference_ms_per_sample': infer_ms,
        # --- standardized (model-space) metrics, full vector and per block ---
        'MSE_std': float(np.mean((Yp_std - Yts) ** 2)),
        'MAE_std': float(np.mean(np.abs(Yp_std - Yts))),
        'RMSE_std': float(np.sqrt(np.mean((Yp_std - Yts) ** 2))),
        'R2_std_full': r2_score(Yts, Yp_std),
        'R2_std_primal': r2_score(Yts[:, B.x], Yp_std[:, B.x]),
        'R2_std_lambda': r2_score(Yts[:, B.lam], Yp_std[:, B.lam]),
        'R2_std_mu': r2_score(Yts[:, B.mu], Yp_std[:, B.mu]),
        'R2_std_z': r2_score(Yts[:, B.z], Yp_std[:, B.z]),
        # --- physical-unit metrics ---
        'R2_Pg': r2_score(Yt[:, idx['Pg']], Yp[:, idx['Pg']]),
        'RMSE_Pg_MW': float(np.sqrt(np.mean((Yp[:, idx['Pg']] - Yt[:, idx['Pg']]) ** 2)) * b),
        'MAE_Pg_MW': float(np.mean(np.abs(Yp[:, idx['Pg']] - Yt[:, idx['Pg']])) * b),
    }
    if is_dc:
        res['RMSE_theta_deg'] = float(np.degrees(np.sqrt(np.mean((Yp[:, idx['Va']] - Yt[:, idx['Va']]) ** 2))))
    else:
        res['RMSE_Vm_pu'] = float(np.sqrt(np.mean((Yp[:, idx['Vm']] - Yt[:, idx['Vm']]) ** 2)))
        res['R2_Vm'] = r2_score(Yt[:, idx['Vm']], Yp[:, idx['Vm']])

    # --- constraint residuals: raw prediction, then after hard projection ---
    ineq_raw, bal_raw = residual_stats(phys, Yp, Pd[te], Qd[te])
    Yc = phys.clip(Yp)
    ineq_clip, bal_clip = residual_stats(phys, Yc, Pd[te], Qd[te])
    screen_pass = (ineq_clip <= args.tol_ineq) & (bal_clip <= args.tol_bal)
    res.update({
        'raw_ineq_violation_rate_pct': float(100 * np.mean(ineq_raw > args.tol_ineq)),
        'ineq_violation_rate_after_clip_pct': float(100 * np.mean(ineq_clip > args.tol_ineq)),
        'max_ineq_residual_after_clip': float(ineq_clip.max()),
        'balance_residual_MW_mean': float(bal_clip.mean() * b),
        'balance_residual_MW_max': float(bal_clip.max() * b),
        'screen_pass_rate_pct': float(100 * screen_pass.mean()),
    })
    print(json.dumps(res, indent=2))
    with open(os.path.join(out_dir, 'results.json'), 'w') as f: json.dump(res, f, indent=2)

    # ---- artefacts ----
    model.save_weights(os.path.join(out_dir, 'gi_lstm.weights.h5'))
    np.savez(os.path.join(out_dir, 'scalers.npz'), x_mu=xs.mu, x_sd=xs.sd, l_mu=ls.mu, l_sd=ls.sd,
             y_mu=ys.mu, y_sd=ys.sd)
    sio.savemat(os.path.join(out_dir, f'{tag}_lstm_pred.mat'), {
        'run_id': rid[te], 'y_lstm': Yp, 'y_clip': Yc, 'y_ipm': Yt,
        'screen_pass': screen_pass.astype(np.float64),
        'nx': meta['nx'], 'nlam': meta['nlam'], 'nmu': meta['nmu'],
    })
    try:
        import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
        plt.figure(figsize=(4, 3))
        plt.semilogy(hist.history['loss'], label='train'); plt.semilogy(hist.history['val_loss'], label='validation')
        plt.xlabel('epoch'); plt.ylabel('grid-informed loss'); plt.legend(); plt.tight_layout()
        plt.savefig(os.path.join(out_dir, 'loss.png'), dpi=200)
    except Exception as e:
        print('plot skipped:', e)
    print(f'artefacts written to {out_dir}')


if __name__ == '__main__':
    main()